# Coursework 2 Template
This stack contains the code template for achieving the second coursework. Students must fill in their code to this template and submit the whole stack as part of the coursework submission.
